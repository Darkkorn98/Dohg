/* PLACEHOLDER – Replace with full animated JSX from Canvas */
const DylanHyperspaceResume = () => <div>Loading résumé...</div>;
export default DylanHyperspaceResume;